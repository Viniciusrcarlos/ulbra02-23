<?php

class Pessoa {
    public string $nome;
    public int $idade;

    public function andar(){
        return "A pessoa está andando";
    }
}

$pessoa = New Pessoa();
$pessoa->nome = "Vini";
$pessoa->idade = "20";
echo "<prev>";
var_dump($pessoa);
die;
