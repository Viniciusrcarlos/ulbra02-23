<$php

phpinfo();