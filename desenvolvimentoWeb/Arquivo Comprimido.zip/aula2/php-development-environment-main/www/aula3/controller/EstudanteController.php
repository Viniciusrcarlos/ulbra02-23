<?php

class EstudanteController
{
    public function Listar()
    {
        
    }
}