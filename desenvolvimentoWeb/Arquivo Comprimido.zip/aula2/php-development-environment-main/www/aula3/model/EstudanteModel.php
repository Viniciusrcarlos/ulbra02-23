<?php

class EstudanteModel
{
    private int $idade;
    private string $nome;
    //getters and setters

    public function ListarModel(): array
    {
        return [
            [
                "nome" => "Vinicius Raupp"
            ],
            [
                "nome" => "Lauren Prusch"
            ]
        ];
    }
    public function SalvarModel()
    {
        echo "Estudante salvo com sucesso!!!";
    }
}
