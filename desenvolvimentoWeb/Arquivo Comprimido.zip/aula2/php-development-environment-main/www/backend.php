<?php

$username = $_POST["username"];
$password = $_POST["password"];

echo "O usuario {$username} está tentando logar.\n";
echo "Com a senha: {$password}";

$nota1 = 6;
$nota2 = 8;
$media = ($nota1+$nota2)/2;

echo "A média das notas é: {$media}";