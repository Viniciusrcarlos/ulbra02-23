<?php

class EstudanteModel
{
    private int $idade;

    private string $nome;

    //Getters and setters

    public function listarModel(): array
    {
        //$array = array();
        //$array = [];
        return [
            [
                "nome" => "Vinicius Raupp"
            ],
            [
                "nome" => "Lauren Prusch"
            ]
        ];
    }

    public function salvarModel()
    {
        echo "Estudante salvo com sucesso!";
    }
}