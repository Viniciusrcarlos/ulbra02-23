package com.aula.aplicacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
