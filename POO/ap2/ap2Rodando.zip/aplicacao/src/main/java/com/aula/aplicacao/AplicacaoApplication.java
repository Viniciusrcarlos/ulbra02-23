package com.aula.aplicacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicacaoApplication.class, args);
	}

}
