package com.example.tdebancodedados.repositories;

import com.example.tdebancodedados.entities.Atleta;
import org.springframework.data.repository.CrudRepository;

public interface AtletaRepository extends CrudRepository<Atleta, Long> {
}
