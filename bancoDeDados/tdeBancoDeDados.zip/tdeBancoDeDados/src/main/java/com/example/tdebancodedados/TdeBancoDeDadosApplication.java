package com.example.tdebancodedados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TdeBancoDeDadosApplication {

    public static void main(String[] args) {
        SpringApplication.run(TdeBancoDeDadosApplication.class, args);
    }

}
