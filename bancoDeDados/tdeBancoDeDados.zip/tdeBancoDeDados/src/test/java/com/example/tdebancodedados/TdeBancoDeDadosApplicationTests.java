package com.example.tdebancodedados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TdeBancoDeDadosApplicationTests {

    @Test
    void contextLoads() {
    }

}
